import Header from "./Header.tsx";
import {Link, Outlet} from "react-router-dom";
import {useState} from "react";


function TextInput({title}) {
    return (
        <div className="flex flex-col gap-2 w-full">
            <label className="text-gray-600 text-sm font-light">{title}</label>
            <input type="text" className="border-2 border-gray-300 rounded-lg p-2 w-full"/>
        </div>
    )
}

function SkillSelect({title}) {
    const [isClicked, setIsClicked] = useState(false)
    return (
        <div
            data-isSelected={isClicked}
            onClick={() => setIsClicked(!isClicked)}
            className="text-sm transition transition-all ease-in-out delay-1000 font-semibold  py-1.5 px-4 bg-gray-300 data-[isSelected=true]:bg-gradient-to-br from-indigo-200 to-cyan-400 rounded-3xl">{title}</div>
    )
}

export default function Intro4() {
    const skills = ["Python", "React", ".NET", "Java", "Data Science", "Go", "Node.js", "Docker", "Team Leading", "CI/CD", "UI/UX"]

    return (
        <>
            <div className="h-screen max-h-screen w-screen flex flex-row justify-center bg-gray-100">
                <div className="h-screen max-h-screen w-[550px] border-x-2 border-x-gray-300 gap-4 flex p-20 flex-col bg-gray-50 items-center justify-center">

                    <h1 className="text-3xl font-bold text-purple-700 text-wrap text-center mb-6">Tell us your skills:</h1>

<div className="flex flex-row flex-wrap gap-2">
    {skills.map(skill => (
        <SkillSelect title={skill}/>
    ))}


</div>


                    <Link to="/intro5" className="text-2xl mt-8 w-full text-center border-4 border-gray-300 py-3 px-10 rounded-2xl hover:cursor-pointer hover:bg-gray-100">Start learning!</Link>

                </div>
            </div>

        </>
    )
}