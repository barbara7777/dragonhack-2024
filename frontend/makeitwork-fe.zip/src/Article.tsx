import {Link} from "react-router-dom";

export default function Article() {
    return (
        <div className="flex flex-col gap-2 grow">
            <img
                className="drop-shadow-2xl"
                src="https://hips.hearstapps.com/hmg-prod/images/beautiful-smooth-haired-red-cat-lies-on-the-sofa-royalty-free-image-1678488026.jpg?crop=1xw:0.84415xh;center,top"/>

            <div className="flex flex-col grow gap-8 px-8 py-6">
                <h1 className="text-2xl font-extrabold">Article title</h1>
                <div className="grow bg-black"></div>
                {/*    Action button */}
                <Link to="" className="w-full rounded-lg p-2 text-center font-bold border-gray-400 border-2 bg-gray-200 hover:bg-gray-300 hover:drop-shadow-2xl">Make your CV rock!</Link>
            </div>

        </div>
    )
}
