import Header from "./Header.tsx";
import {Link, Outlet} from "react-router-dom";


function TextInput({title}) {
    return (
        <div className="flex flex-col gap-2 w-full">
            <label className="text-gray-600 text-sm font-light">{title}</label>
            <input type="text" className="border-2 border-gray-300 rounded-lg p-2 w-full"/>
        </div>
    )
}

export default function Intro2() {
    return (
        <>
            <div className="h-screen max-h-screen w-screen flex flex-row justify-center bg-gray-100">
                <div className="h-screen max-h-screen w-[550px] border-x-2 border-x-gray-300 gap-4 flex p-20 flex-col bg-gray-50 items-center justify-center">

                    <h1 className="text-3xl font-bold text-purple-700 text-wrap mb-6">Let's get to know each other!</h1>

                    <TextInput title="Username"/>
                    <div className="flex flex-row gap-6 mt-6 items-center">
                        <div className="w-32 h-32 bg-[url('logo.png')] bg-cover grayscale rounded-full"></div>
                        <div className="flex flex-col gap-4 grow">
                            <div className="py-2 px-4 border-2 border-gray-300 rounded-xl w-full text-center">Upload Image</div>
                            <div className="py-2 px-4 border-2 border-gray-300 rounded-xl w-full text-center">Generate Image</div>
                        </div>
                    </div>
                    <TextInput title="Name"/>

                    <TextInput title="Surname"/>



                    <Link to="/intro3" className="text-2xl mt-8 border-4 border-gray-300 py-3 px-10 rounded-2xl hover:cursor-pointer text-center w-full hover:bg-gray-100">→</Link>

                </div>
            </div>

        </>
    )
}