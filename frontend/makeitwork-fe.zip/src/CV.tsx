export default function CV() {
    const skills = [
        "React",
        "Team Leading",
        "Node.js",
        "Python",
        "Teamwork",
        "Docker"
    ]
    return (
        <div className="grow flex flex-col p-8 gap-8  ">

            <div className="bg-[url(cv.png)] w-full h-full bg-contain bg-no-repeat bg-center"></div>

        </div>
    )

}